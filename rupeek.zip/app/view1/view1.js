'use strict';
angular.module('myApp.view1', ['ngRoute'])

  .config(['$routeProvider', function ($routeProvider) {
    $routeProvider.when('/view1', {
      templateUrl: 'view1/view1.html',
      controller: 'View1Ctrl'
    });
  }])

  .controller('View1Ctrl', ['$scope', '$http', function ($scope, $http) {
    $scope.data;
    $scope.data_copy;
    $scope.sort_flag;
    $scope.sort_name;
    $scope.lookAhead;
    $scope.description;
    $scope.getTotalLikes;
    $scope.totalLikes = 0;
    $scope.searchedName = '';
    var _$scope = $scope;
    $scope.alert1 = function () {
      $http.get('http://www.mocky.io/v2/5bdd28dd32000075008c6227').then((response) => {
        _$scope.data = response.data.data;
        _$scope.data_copy = response.data.data;
        $scope.getTotalLikes(_$scope.data);
      });
    }
    $scope.getTotalLikes = (data) => {
      $scope.totalLikes = 0;
      for (var x in $scope.data) {
        $scope.totalLikes += $scope.data[x].likes;
      }
    }
    $scope.getRating = (number) => {
      if (number % 1 != 0) {
        number = number - 0.5 + 1;
      }
      return new Array(number);
    }
    $scope.search = () => {
      var _$scope = $scope;
      $scope.data = $scope.data_copy;
      let searchedName = ($scope.searchedName).toLowerCase();
      $scope.data = $scope.data.filter(function (obj, index) {
        return obj.place.toLowerCase().indexOf(searchedName) !== -1;
      });
      setTimeout(() => {
        _$scope.lookAhead = _$scope.data.map(a => a.place);
      }, 0);

      $scope.clearSearch();
    }
    $scope.clearSearch = () => {
      if ($scope.searchedName == '')
        $scope.data = $scope.data_copy;
    }
    $scope.sortByFund = () => {
      $scope.sort_flag = !$scope.sort_flag;
      if ($scope.sort_flag)
        $scope.sortAscending('ratings');
      else
        $scope.sortDscending('ratings');
    }
    $scope.sortByDate = () => {
      $scope.sort_flag = !$scope.sort_flag;
      if ($scope.sort_flag)
        $scope.sortAscending('likes');
      else
        $scope.sortDscending('likes');
    }
    $scope.sortAscending = (params) => {
      if (params == 'likes') {
        $scope.data.sort((a, b) => {
          return new Date(a[params]) - new Date(b[params]);
        })
      }
      else {
        $scope.data.sort((a, b) => {
          return a[params] - b[params];
        })
      }
    }
    $scope.sortDscending = (params) => {
      if (params == 'likes') {
        $scope.data.sort((a, b) => {
          return new Date(b[params]) - new Date(a[params]);
        })
      }
      else {
        $scope.data.sort((a, b) => {
          return b[params] - a[params];
        })
      }
    }
  }]);